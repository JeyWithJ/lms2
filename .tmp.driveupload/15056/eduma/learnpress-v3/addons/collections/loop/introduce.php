<?php
/**
 * Loop collection introduce
 *
 * @author  ThimPress
 * @package LearnPress/Templates
 * @version 1.0
 */

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>
<div class="collection-introduce">
	<?php echo get_the_excerpt(); ?>
</div>